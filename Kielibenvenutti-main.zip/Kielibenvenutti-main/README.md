# Boas vindas ao meu perfil! 😛

Meu nome é Kieli Benvenutti

- Estou estudando na Alura
- Estou me desenvolvendo na linguagem JavaScript
- Utilizo esse espaço para minha organização e compartilhamento dos meu projetos desenvolvidos

  **Você entrar em contato comigo** 📫
  
kieli.benveutti@gmail.com

![](https://media1.tenor.com/m/tbAlzAsBICsAAAAC/funny-laughing.gif) 
